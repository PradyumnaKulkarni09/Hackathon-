"""Evaluate recall on questions whose answers are known from data/ground_truth.json.

  python eval.py                      # uses existing data/, ingests if empty
  python eval.py --reset --embedder hash
Reports exact-answer accuracy for 'last time' questions, recall@5 for event lookups, count accuracy, latency.
"""
import argparse
import csv
import json
import statistics
from pathlib import Path

from airecall.engine import Recall

NODE_WORD = {"edge-01": "edge-01", "edge-02": "node 2", "edge-03": "device 3", "edge-04": "edge-04", "edge-05": "edge-05"}


def build_cases(gt):
    t, limit = gt["truth"], gt["spike_limit"]
    cases = []

    def by_node(kind):
        d = {}
        for e in t[kind]:
            d.setdefault(e["node"], []).append(e["ts"])
        return d

    for node, tss in by_node("voltage_spike").items():
        w = NODE_WORD[node]
        cases.append(("last-numeric", f"When was the last time voltage went above {limit:g} on {w}?", node, tss[-1]))
        cases.append(("first-numeric", f"first time voltage exceeded {limit:g} on {w}", node, tss[0]))
        cases.append(("count-numeric", f"How many times did voltage go above {limit:g} on {w}?", node, len(tss)))
    for node, tss in by_node("link_down").items():
        cases.append(("last-event", f"when did the link go down on {NODE_WORD[node]}", node, tss[-1]))
    for node, tss in by_node("over_temp").items():
        cases.append(("last-event", f"last over temperature shutdown on {NODE_WORD[node]}", node, tss[-1]))
    for node, tss in by_node("sensor_timeout").items():
        cases.append(("count-event", f"how many sensor read timeouts on {NODE_WORD[node]}", node, len(tss)))
        cases.append(("last-event", f"latest sensor timeout on {NODE_WORD[node]}", node, tss[-1]))
    return cases


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--embedder", default="auto")
    ap.add_argument("--provider", default="auto")
    ap.add_argument("--reset", action="store_true")
    a = ap.parse_args()

    gt = json.loads((Path(a.data) / "ground_truth.json").read_text())
    r = Recall(a.data, a.embedder, a.provider)
    if a.reset or not r.store.n_logs():
        print(r.ingest(f"{a.data}/edge.log", reset=True))

    rows, lat = [], []
    for kind, q, node, expect in build_cases(gt):
        res = r.ask(q)
        ev = res["evidence"]
        if kind.startswith("count"):
            import re
            m = re.search(r"(\d+)\s+(?:reading|matching)", res["answer"])
            got = int(m.group(1)) if m else None
            ok = got == expect
            hit5 = ok
        else:
            got = ev[0]["ts"] if ev else None
            ok = got == expect and (not ev or ev[0]["node"] == node)
            hit5 = any(e["ts"] == expect and e["node"] == node for e in ev[:5])
        lat.append(res["latency_ms"])
        rows.append([kind, q, expect, got, int(ok), int(hit5), res["latency_ms"]])

    kinds = sorted({x[0] for x in rows})
    print(f"\nembedder: {r.emb.name} on {r.emb.device}")
    print(f"{'type':<15}{'n':>4}{'exact':>8}{'recall@5':>10}")
    for k in kinds:
        rs = [x for x in rows if x[0] == k]
        print(f"{k:<15}{len(rs):>4}{sum(x[4] for x in rs) / len(rs):>8.0%}{sum(x[5] for x in rs) / len(rs):>10.0%}")
    print(f"{'ALL':<15}{len(rows):>4}{sum(x[4] for x in rows) / len(rows):>8.0%}{sum(x[5] for x in rows) / len(rows):>10.0%}")
    print(f"latency ms: median {statistics.median(lat):.1f}, p95 {sorted(lat)[int(0.95 * len(lat)) - 1]:.1f}")
    for x in rows:
        if not x[4]:
            print("MISS:", x[1], "expected", x[2], "got", x[3])
    out = Path(a.data) / "eval_report.csv"
    with open(out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["type", "question", "expected", "got", "exact", "recall_at_5", "latency_ms"])
        w.writerows(rows)
    print("saved", out)


if __name__ == "__main__":
    main()
