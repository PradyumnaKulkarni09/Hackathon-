"""Export a sentence-embedding model to ONNX with STATIC shapes (NPU compilers prefer fixed shapes).

  pip install torch transformers onnx onnxruntime tokenizers
  python export_onnx.py                       # all-MiniLM-L6-v2, seq len 64  -> models/minilm.onnx + tokenizer.json
  python export_onnx.py --model BAAI/bge-small-en-v1.5 --seq 64

Needs internet once (to download the open-weight model from Hugging Face). After that everything is local.
Check the model licence is acceptable for your organisation before using it.
"""
import argparse
from pathlib import Path

import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer

ap = argparse.ArgumentParser()
ap.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2")
ap.add_argument("--seq", type=int, default=64)
ap.add_argument("--out", default="models")
a = ap.parse_args()
out = Path(a.out)
out.mkdir(exist_ok=True)


class Wrap(torch.nn.Module):
    """token ids -> L2-normalised mean-pooled sentence vector (pooling lives inside the graph)."""

    def __init__(self, m):
        super().__init__()
        self.m = m

    def forward(self, input_ids, attention_mask):
        h = self.m(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        mask = attention_mask.unsqueeze(-1).to(h.dtype)
        pooled = (h * mask).sum(1) / mask.sum(1).clamp(min=1e-9)
        return torch.nn.functional.normalize(pooled, dim=-1)


tok = AutoTokenizer.from_pretrained(a.model)
model = AutoModel.from_pretrained(a.model, attn_implementation="eager").eval()
wrap = Wrap(model).eval()
tok.backend_tokenizer.save(str(out / "tokenizer.json"))

enc = tok(["link down on interface eth0"], padding="max_length", truncation=True, max_length=a.seq, return_tensors="pt")
ids, mask = enc["input_ids"].int(), enc["attention_mask"].int()
path = out / "minilm.onnx"
kw = dict(input_names=["input_ids", "attention_mask"], output_names=["embedding"], opset_version=17)
try:
    torch.onnx.export(wrap, (ids, mask), str(path), dynamo=False, **kw)
except TypeError:  # older torch without the dynamo flag
    torch.onnx.export(wrap, (ids, mask), str(path), **kw)
print("wrote", path)

# sanity check: ONNX output must match PyTorch
import onnxruntime as ort

sess = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
dt = np.int32 if "int32" in sess.get_inputs()[0].type else np.int64
got = sess.run(None, {"input_ids": ids.numpy().astype(dt), "attention_mask": mask.numpy().astype(dt)})[0]
ref = wrap(ids, mask).detach().numpy()
cos = float((got * ref).sum() / (np.linalg.norm(got) * np.linalg.norm(ref)))
print(f"cosine(onnx, torch) = {cos:.6f}  (should be ~1.0)  shape={got.shape}")
print(f"Done. Now run: python main.py ingest data/edge.log --reset --embedder onnx")
